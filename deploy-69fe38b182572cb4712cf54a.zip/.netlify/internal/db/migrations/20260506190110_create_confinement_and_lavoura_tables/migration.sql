CREATE TYPE "lavoura_expense_category" AS ENUM('trator', 'semente', 'fertilizante', 'combustivel', 'mao_de_obra', 'outro');--> statement-breakpoint
CREATE TABLE "confinement_entries" (
	"id" serial PRIMARY KEY,
	"number" text NOT NULL,
	"entry_date" text NOT NULL,
	"entry_weight" numeric(10,2) NOT NULL,
	"exit_date" text,
	"status" text DEFAULT 'ativo' NOT NULL,
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "confinement_monthly" (
	"id" serial PRIMARY KEY,
	"confinement_id" integer NOT NULL,
	"month" integer NOT NULL,
	"year" integer NOT NULL,
	"current_weight" numeric(10,2),
	"feed_kg" numeric(10,2) DEFAULT '0',
	"corn_kg" numeric(10,2) DEFAULT '0',
	"oats_kg" numeric(10,2) DEFAULT '0',
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "lavoura_expenses" (
	"id" serial PRIMARY KEY,
	"expense_date" text NOT NULL,
	"category" "lavoura_expense_category" NOT NULL,
	"description" text NOT NULL,
	"amount" numeric(10,2) NOT NULL,
	"quantity" numeric(10,2),
	"unit" text,
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "confinement_monthly" ADD CONSTRAINT "confinement_monthly_confinement_id_confinement_entries_id_fkey" FOREIGN KEY ("confinement_id") REFERENCES "confinement_entries"("id");