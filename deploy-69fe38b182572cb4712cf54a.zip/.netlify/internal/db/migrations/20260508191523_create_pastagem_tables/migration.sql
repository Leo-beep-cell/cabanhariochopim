CREATE TABLE "pastagem_entries" (
	"id" serial PRIMARY KEY,
	"number" text NOT NULL,
	"entry_date" text NOT NULL,
	"entry_weight" numeric(10,2) NOT NULL,
	"pasture_name" text,
	"status" text DEFAULT 'ativo' NOT NULL,
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "pastagem_weight_records" (
	"id" serial PRIMARY KEY,
	"pastagem_id" integer NOT NULL,
	"weight" numeric(10,2) NOT NULL,
	"recorded_at" text NOT NULL,
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "pastagem_weight_records" ADD CONSTRAINT "pastagem_weight_records_pastagem_id_pastagem_entries_id_fkey" FOREIGN KEY ("pastagem_id") REFERENCES "pastagem_entries"("id");