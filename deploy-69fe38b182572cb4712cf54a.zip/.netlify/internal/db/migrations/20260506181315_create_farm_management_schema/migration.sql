CREATE TYPE "animal_type" AS ENUM('cavalo', 'porco', 'ovelha', 'boi');--> statement-breakpoint
CREATE TYPE "product_type" AS ENUM('alimento', 'medicamento', 'suplemento');--> statement-breakpoint
CREATE TABLE "animals" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"type" "animal_type" NOT NULL,
	"breed" text,
	"birth_date" text,
	"current_weight" numeric(10,2),
	"price_per_kg" numeric(10,2),
	"status" text DEFAULT 'ativo' NOT NULL,
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "births" (
	"id" serial PRIMARY KEY,
	"mother_id" integer,
	"animal_type" "animal_type" NOT NULL,
	"count" integer DEFAULT 1 NOT NULL,
	"birth_date" text NOT NULL,
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "consumption_records" (
	"id" serial PRIMARY KEY,
	"animal_id" integer,
	"product_id" integer NOT NULL,
	"quantity" numeric(10,2) NOT NULL,
	"month" integer NOT NULL,
	"year" integer NOT NULL,
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "products" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"type" "product_type" NOT NULL,
	"unit" text DEFAULT 'kg' NOT NULL,
	"price_per_unit" numeric(10,2),
	"current_stock" numeric(10,2) DEFAULT '0' NOT NULL,
	"min_stock" numeric(10,2) DEFAULT '0',
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "weight_records" (
	"id" serial PRIMARY KEY,
	"animal_id" integer NOT NULL,
	"weight" numeric(10,2) NOT NULL,
	"recorded_at" text NOT NULL,
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "births" ADD CONSTRAINT "births_mother_id_animals_id_fkey" FOREIGN KEY ("mother_id") REFERENCES "animals"("id");--> statement-breakpoint
ALTER TABLE "consumption_records" ADD CONSTRAINT "consumption_records_animal_id_animals_id_fkey" FOREIGN KEY ("animal_id") REFERENCES "animals"("id");--> statement-breakpoint
ALTER TABLE "consumption_records" ADD CONSTRAINT "consumption_records_product_id_products_id_fkey" FOREIGN KEY ("product_id") REFERENCES "products"("id");--> statement-breakpoint
ALTER TABLE "weight_records" ADD CONSTRAINT "weight_records_animal_id_animals_id_fkey" FOREIGN KEY ("animal_id") REFERENCES "animals"("id");